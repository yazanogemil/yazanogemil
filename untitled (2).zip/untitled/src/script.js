// Cart tracking
let cart = [];
let cartCount = 0;

function updateCartDisplay() {
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = '';

    cart.forEach(item => {
        const li = document.createElement('li');
        li.textContent = `${item.name} - $${item.price}`;
        cartItems.appendChild(li);
    });

    document.querySelector('.cart-button').textContent = `Cart (${cartCount})`;
}

// Add event listeners to 'Add to Cart' buttons
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', function () {
        const productId = this.getAttribute('data-id');
        const productName = this.getAttribute('data-name');
        const productPrice = parseFloat(this.getAttribute('data-price'));

        const wallpaperInput = document.getElementById(`wallpaper${productId}`);
        const wallpaperFile = wallpaperInput.files[0];
        
        if (!wallpaperFile) {
            alert('Please upload a wallpaper for this golf ball.');
            return;
        }

        cart.push({ id: productId, name: productName, price: productPrice });
        cartCount++;
        updateCartDisplay();
        alert('Added to cart with your custom wallpaper!');
    });
});

// Handle checkout button (Placeholder action)
document.getElementById('checkout-button').addEventListener('click', function () {
    alert('Checkout functionality not yet implemented.');
});
